//定数
export default {
    fps: 60,
    duration: 3,
    lineHeight:1.2,
    bigLines:8 ,
    mediumLines:11,
    smallLines:16,
    fix:{
        smal:38,
        big:16,
        medium:25,
    },
    defaultColor:'#fff',
    defaultLayer:'base',
    defaultFont:'MS PGothic',
    opacity:1,
};